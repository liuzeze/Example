package com.future.utilslib.view.statu;

import android.content.Context;

import com.future.utilslib.R;

/**
 * @author : liuze
 * @e-mail : 835052259@qq.com
 * @date : 2019/10/9-10:55
 * @desc : 修改内容
 * @version: 1.0
 */
public class LoadingView extends BaseStatusView {


    public LoadingView(Context context) {
        super(context, R.layout.layout_status);
        setText("正在加载");
        setTextVisible(true);
        setImgVisible(false);
        setRetryVisible(false);
        setLoading(true);
    }


}
