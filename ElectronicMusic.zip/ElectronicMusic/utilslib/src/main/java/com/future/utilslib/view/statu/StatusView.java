package com.future.utilslib.view.statu;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.IdRes;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import org.jetbrains.annotations.NotNull;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2018-10-22       创建class
 */
public class StatusView extends FrameLayout {

    private static final int LOADINGVIEW = 1;
    private static final int ERRORVIEW = 2;
    private static final int EMPTYVIEW = 3;
    private static final int NETERRORVIEW = 4;



    private View mContentView;
    private View mCurrentView;
    private ConfigBuild configBuild;

    public StatusView(@NonNull Context context) {
        this(context, null);
    }

    public StatusView(@NonNull Context context, @Nullable AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public StatusView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        initAttrs(context, attrs, defStyleAttr, 0);
        setBackgroundColor(Color.WHITE);
    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public StatusView(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        initAttrs(context, attrs, defStyleAttr, defStyleRes);
    }

    private void initAttrs(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        configBuild = new ConfigBuild(
                new LoadingView(getContext()),
                new ErrorView(getContext()),
                new EmptyView(getContext()),
                new NetView(getContext()));
    }

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();
        if (getChildCount() == 1) {
            View contentView = getChildAt(0);
            setContentView(contentView);

        }
    }


    public static StatusView init(Activity activity) {
        View contentView = ((ViewGroup) activity.findViewById(android.R.id.content)).getChildAt(0);
        return bindView(contentView);
    }

    public static StatusView init(Activity activity, @IdRes int resId) {
        View rootView = ((ViewGroup) activity.findViewById(android.R.id.content)).getChildAt(0);
        View contentView = rootView.findViewById(resId);
        return bindView(contentView);
    }

    public static StatusView init(View contentView) {
        return bindView(contentView);
    }

    public static StatusView init(Fragment fragment) {
        View view = fragment.getView();
        return bindView(view);
    }

    public static StatusView init(Fragment fragment, @IdRes int resourceId) {
        View rootView = fragment.getView();
        View contentView = null;
        if (rootView != null) {
            contentView = rootView.findViewById(resourceId);
        }
        return bindView(contentView);
    }

    private static StatusView bindView(View contentView) {

        if (contentView == null) {
            return null;
//            new Throwable("contentView can not be null");
        }
        ViewGroup parent = (ViewGroup) contentView.getParent();
        ViewGroup.LayoutParams layoutParams = contentView.getLayoutParams();
        int index = parent.indexOfChild(contentView);

        parent.removeView(contentView);
        StatusView statusView = new StatusView(contentView.getContext());
        statusView.addView(contentView);
        statusView.setContentView(contentView);
        if (contentView.getVisibility() == View.GONE) {
            statusView.setVisibility(GONE);
        }
        parent.addView(statusView, index, layoutParams);
        //兼容linearLayout的权重属性
        if (layoutParams instanceof LinearLayout.LayoutParams) {
            if (((LinearLayout.LayoutParams) layoutParams).weight == 1
                    && layoutParams.width == 0) {
                ViewGroup.LayoutParams childParams = contentView.getLayoutParams();
                childParams.width = LinearLayout.LayoutParams.MATCH_PARENT;
                contentView.setLayoutParams(childParams);
            }
        }

        return statusView;
    }

    private void setContentView(View contentView) {
        mContentView = mCurrentView = contentView;

    }


    public void showEmptyView(String emptyText) {
        getConfigBuild().setEmptyText(emptyText);

        showEmptyView();
    }

    public void showErrorView(String errorText) {
        getConfigBuild().setErrorText(errorText);
        showErrorView();
    }

    public void showNetErrorView(String errorText) {
        getConfigBuild().setNetText(errorText);
        showNetErrorView();
    }

    public void showLoadingView(String loadText) {
        getConfigBuild().setLoadText(loadText);
        showLoadingView();
    }

    public void showLoadingView() {
        switchView(configBuild.loadingView);
    }


    public void showContentView() {
        switchView(mContentView);
    }


    public void showErrorView() {
        switchView(configBuild.errorView);
    }

    public void showNetErrorView() {
        switchView(configBuild.netView);
    }


    public void showEmptyView() {
        switchView(configBuild.emptyView);
    }


    private synchronized void switchView(View convertView) {
        //当前已显示
        if (mCurrentView == convertView) {
            return;
        }
        //当前显示的是UI View  要显示其他View  不显示UI View
        if (mCurrentView == mContentView) {
            mContentView.setVisibility(GONE);
            mCurrentView = convertView;
            addView(mCurrentView);
        } else {
            //当前显示的不是UI View
            removeView(mCurrentView);
            mCurrentView = convertView;
            if (convertView == mContentView) {
                if (mContentView.getVisibility() == View.GONE) {
                    mContentView.setVisibility(VISIBLE);
                }
            } else {
                addView(mCurrentView);

            }
        }
    }


    public ConfigBuild getConfigBuild() {
        return configBuild;
    }


    public StatusView setEmptyView(@NotNull View view) {

        configBuild.emptyView =  new BaseStatusView(getContext(),view);
        return this;

    }

    public StatusView setLoadView(@NotNull View view) {
        configBuild.loadingView = new BaseStatusView(getContext(),view);
        return this;

    }

    public StatusView setErrorView(@NotNull View view) {
        configBuild.errorView =  new BaseStatusView(getContext(),view);
        return this;

    }

    public StatusView setNetErrorView(@NotNull View view) {
        configBuild.netView =  new BaseStatusView(getContext(),view);
        return this;

    }

    public StatusView setEmptyView(@LayoutRes int layoutId) {
        setEmptyView(new BaseStatusView(getContext(),layoutId));
        return this;

    }

    public StatusView setLoadView(@LayoutRes int layoutId) {
        setLoadView(new BaseStatusView(getContext(),layoutId));
        return this;

    }

    public StatusView setErrorView(@LayoutRes int layoutId) {
        setErrorView(new BaseStatusView(getContext(),layoutId));
        return this;

    }

    public StatusView setNetErrorView(@LayoutRes int layoutId) {
        setNetErrorView(new BaseStatusView(getContext(),layoutId));
        return this;

    }

}
