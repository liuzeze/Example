package com.future.utilslib.view.statu;

import android.graphics.drawable.Drawable;
import android.media.Image;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class StatusViewHolder {

    private SparseArray<View> views;
    private View convertView;

    private StatusViewHolder(View view) {
        convertView = view;
        views = new SparseArray<>();
    }

    public static StatusViewHolder create(View view) {
        return new StatusViewHolder(view);
    }

    public <T extends View> T getView(int viewId) {
        View view = views.get(viewId);
        if (view == null) {
            view = convertView.findViewById(viewId);
            views.put(viewId, view);
        }
        return (T) view;
    }

    public View getConvertView() {
        return convertView;
    }

    public void setText(int viewId, String text) {
        if (text != null) {
            View view = getView(viewId);
            if (view != null) {
                TextView textView = (TextView) view;
                textView.setText(text);
            }
        }
    }

    public void setText(int viewId, int textId) {
        View view = getView(viewId);
        if (view != null) {
            TextView textView = (TextView) view;
            textView.setText(textId);
        }
    }

    public void setTextColor(int viewId, int colorId) {
        if (colorId > 0) {
            View view = getView(viewId);
            if (view != null) {
                TextView textView = (TextView) view;
                textView.setTextColor(colorId);
            }
        }
    }

    public void setTextSize(int viewId, int size) {
        if (size > 0) {
            View view = getView(viewId);
            if (view != null) {
                TextView textView = (TextView) view;
                textView.setTextSize(size);
            }
        }
    }

    public void setOnClickListener(int viewId, final View.OnClickListener clickListener) {
        View view = getView(viewId);
        if (view != null) {

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    clickListener.onClick(v);
                }
            });
        }
    }

    public void setImageResource(int viewId, int resId) {
        if (resId > 0) {
            View view = getView(viewId);
            if (view != null) {
                if (view instanceof ImageView) {
                    ((ImageView) view).setImageResource(resId);
                }
            }
        }
    }

    public void setBackgroundResource(int viewId, int resId) {
        if (resId > 0) {
            View view = getView(viewId);
            if (view != null) {
                view.setBackgroundResource(resId);
            }
        }
    }

    public void setBackgroundColor(int viewId, int colorId) {
        if (colorId > 0) {
            View view = getView(viewId);
            if (view != null) {
                view.setBackgroundColor(colorId);
            }
        }
    }

    public void setBackgroundDrawable(int viewId, Drawable drawable) {
        if (drawable != null) {
            View view = getView(viewId);
            if (view != null) {
                view.setBackgroundDrawable(drawable);
            }
        }
    }

    public void setVisibility(int viewId, boolean visible) {
        View view = getView(viewId);
        if (view != null) {
            view.setVisibility(visible ? View.VISIBLE : View.GONE);
        }
    }

    public void setLoadView(int viewId, View view) {
        ViewGroup convertView = (ViewGroup) getConvertView();
        if (convertView.getChildCount() > 0) {
            View childAt = convertView.getChildAt(0);
            ViewGroup.LayoutParams layoutParams = childAt.getLayoutParams();
            convertView.removeViewAt(0);
            ViewGroup parent1 = (ViewGroup) view.getParent();
            if (parent1 != null) {
                parent1.removeView(view);
            }
            convertView.addView(view, 0, layoutParams);
        }
    }
}
