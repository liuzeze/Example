package com.future.utilslib.view.statu;

import android.support.annotation.ColorRes;
import android.view.View;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2018-10-22       创建class
 */
public class ConfigBuild {
    public BaseStatusView loadingView;
    public BaseStatusView errorView;
    public BaseStatusView emptyView;
    public BaseStatusView netView;

    public ConfigBuild(LoadingView loadingView, ErrorView errorView, EmptyView emptyView, NetView netView) {
        this.loadingView = loadingView;
        this.errorView = errorView;
        this.emptyView = emptyView;
        this.netView = netView;
    }


    /*========================加载==================*/
    public ConfigBuild setLoading(boolean isVisible) {
        loadingView.setLoading(isVisible);
        return this;
    }


    public ConfigBuild setLoadTextVisible(boolean isVisible) {
        loadingView.setTextVisible(isVisible);
        return this;
    }

    public ConfigBuild setLoadTextColor(@ColorRes int color) {
        loadingView.setTextColor(color);
        return this;
    }

    public ConfigBuild setLoadText(String text) {
        loadingView.setText(text);
        return this;
    }

    public ConfigBuild setLoadTextSize(int textSize) {
        loadingView.setTextSize(textSize);
        return this;
    }
    /*=============================空页面===========*/


    public ConfigBuild setEmptyImgVisible(boolean isVisible) {
        emptyView.setImgVisible(isVisible);
        return this;
    }


    public ConfigBuild setEmptyImgRes(int ivRes) {
        emptyView.setImgRes(ivRes);
        return this;
    }

    public ConfigBuild setEmptyTextVisib(boolean isVisible) {
        emptyView.setTextVisible(isVisible);
        return this;
    }

    public ConfigBuild setEmptyTextColor(@ColorRes int color) {
        emptyView.setTextColor(color);
        return this;
    }

    public ConfigBuild setEmptyText(String text) {
        emptyView.setText(text);
        return this;
    }

    public ConfigBuild setEmptyTextSize(int textSize) {
        emptyView.setTextSize(textSize);
        return this;
    }

    public ConfigBuild setEmptyRetryVisible(boolean isVisible) {
        emptyView.setRetryVisible(isVisible);
        return this;
    }

    public ConfigBuild setEmptyRetryTextColor(@ColorRes int color) {
        emptyView.setTextColor(color);
        return this;
    }

    public ConfigBuild setEmptyRetryText(String text) {
        emptyView.setText(text);
        return this;
    }

    public ConfigBuild setEmptyRetryTextSize(int textSize) {
        emptyView.setTextSize(textSize);
        return this;
    }

    public ConfigBuild setEmptyTextClick(View.OnClickListener errorTextClick) {
        emptyView.setTextClick(errorTextClick);
        return this;
    }


    public ConfigBuild setEmptyRetryClick(View.OnClickListener errorTextClick) {
        emptyView.setRetryClick(errorTextClick);
        return this;
    }

    public ConfigBuild setEmptyRetryBackGround(int bgRes) {
        emptyView.setBackgroundResource(bgRes);
        return this;
    }
    /*============================error============*/


    public ConfigBuild setErrorImgVisible(boolean isVisible) {
        errorView.setImgVisible(isVisible);
        return this;
    }

    public ConfigBuild setErrorImgRes(int ivRes) {
        errorView.setImgRes(ivRes);
        return this;
    }

    public ConfigBuild setErrorTextVisib(boolean isVisible) {
        errorView.setTextVisible(isVisible);
        return this;
    }

    public ConfigBuild setErrorTextColor(@ColorRes int color) {
        errorView.setTextColor(color);
        return this;
    }

    public ConfigBuild setErrorText(String text) {
        errorView.setText(text);
        return this;
    }

    public ConfigBuild setErrorTextSize(int textSize) {
        errorView.setTextSize(textSize);
        return this;
    }

    public ConfigBuild setErrorRetryVisib(boolean isVisible) {
        errorView.setRetryVisible(isVisible);
        return this;
    }

    public ConfigBuild setErrorRetryTextColor(@ColorRes int color) {
        errorView.setTextColor(color);
        return this;
    }

    public ConfigBuild setErrorRetryText(String text) {
        errorView.setText(text);
        return this;
    }

    public ConfigBuild setErrorRetryTextSize(int textSize) {
        errorView.setTextSize(textSize);
        return this;
    }

    public ConfigBuild setErrorTextClick(View.OnClickListener errorTextClick) {
        errorView.setTextClick(errorTextClick);
        return this;
    }


    public ConfigBuild setErrorRetryClick(View.OnClickListener errorTextClick) {
        errorView.setRetryClick(errorTextClick);
        return this;
    }

    public ConfigBuild setRetryErrorBackGround(int bgRes) {
        errorView.setBackgroundResource(bgRes);
        return this;
    }



    /*==========================net=======================*/


    public ConfigBuild setNetImgVisible(boolean isVisible) {
        netView.setImgVisible(isVisible);
        return this;
    }


    public ConfigBuild setNetImgRes(int ivRes) {
        netView.setImgRes(ivRes);
        return this;
    }

    public ConfigBuild setNetTextVisib(boolean isVisible) {
        netView.setTextVisible(isVisible);
        return this;
    }

    public ConfigBuild setNetTextColor(@ColorRes int color) {
        netView.setTextColor(color);
        return this;
    }

    public ConfigBuild setNetText(String text) {
        netView.setText(text);
        return this;
    }

    public ConfigBuild setNetTextSize(int textSize) {
        netView.setTextSize(textSize);
        return this;
    }

    public ConfigBuild setNetRetryVisib(boolean isVisible) {
        netView.setRetryVisible(isVisible);
        return this;
    }

    public ConfigBuild setNetRetryTextColor(@ColorRes int color) {
        netView.setTextColor(color);
        return this;
    }

    public ConfigBuild setNetRetryText(String text) {
        netView.setText(text);
        return this;
    }

    public ConfigBuild setNetRetryTextSize(int textSize) {
        netView.setTextSize(textSize);
        return this;
    }


    public ConfigBuild setNetTextClick(View.OnClickListener errorTextClick) {
        netView.setTextClick(errorTextClick);
        return this;
    }


    public ConfigBuild setNetRetryClick(View.OnClickListener errorTextClick) {
        netView.setRetryClick(errorTextClick);
        return this;
    }

    public ConfigBuild setNetRetryBackGround(int bgRes) {
        netView.setBackgroundResource(bgRes);
        return this;
    }

}
