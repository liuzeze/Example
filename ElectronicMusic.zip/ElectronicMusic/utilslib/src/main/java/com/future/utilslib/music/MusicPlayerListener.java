package com.future.utilslib.music;

import android.media.MediaPlayer;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2019-08-14       创建class
 */
public class MusicPlayerListener {
    public void onPrepared(MediaPlayer mp) {

    }

    public void onBufferingUpdate(MediaPlayer mp, int percent) {

    }

    public void onCompletionNext(MediaPlayer mp) {

    }

    public void onCompletion(MediaPlayer mp) {

    }

    public void onError(MediaPlayer mp, int what, int extra) {

    }
}
