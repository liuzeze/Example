package com.future.utilslib.base;

import com.lz.fram.base.FramBaseFragment;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2019-07-16       创建class
 */
public abstract class BaseFragment extends FramBaseFragment{



}
