package com.future.utilslib.dialog;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Handler;
import android.text.TextUtils;
import android.view.*;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import com.future.utilslib.R;
import com.future.utilslib.utils.LzScreenUtils;

import java.util.Timer;
import java.util.TimerTask;


/**
 * @author 刘泽
 */
public class LzAlertDialog {
    private LzAlertDialog mLpAlertDialog;
    private Context context;
    private Dialog dialog;
    private LinearLayout ll_btn_group;
    private TextView txt_title;
    private TextView txt_msg;
    private TextView btn_neg;
    private TextView btn_pos;
    private View mLine;
    private boolean showTitle = false;
    private boolean showMsg = false;
    private boolean showContentView = false;
    private boolean showPosBtn = false;
    private boolean showNegBtn = false;
    private boolean mCancel = true;


    /**
     * 倒计时总时长，默认60000毫秒=60秒
     */
    private int mMillisInFuture = 500;


    /**
     * 倒计时间隔时常，默认1000毫秒=1秒
     */
    private int mCountDownInterval = 1;

    private Timer t;

    private TimerTask tt;
    private FrameLayout mFrameLayout;
    private FrameLayout mDialogRoot;


    public LzAlertDialog(Context context) {
        this.context = context;
        mLpAlertDialog = this;
        WindowManager windowManager = (WindowManager) context
                .getSystemService(Context.WINDOW_SERVICE);
    }

    public LzAlertDialog builder() {
        // 获取Dialog布局
        View view = LayoutInflater.from(context).inflate(
                R.layout.view_alertdialog, null);

        // 获取自定义Dialog布局中的控件
        ll_btn_group = (LinearLayout) view.findViewById(R.id.ll_btn_group);
        mDialogRoot = (FrameLayout) view.findViewById(R.id.fl_dialog_root);
        mFrameLayout = (FrameLayout) view.findViewById(R.id.fl_rootview);
        txt_title = (TextView) view.findViewById(R.id.txt_title);
        txt_title.setVisibility(View.GONE);
        txt_msg = (TextView) view.findViewById(R.id.txt_msg);
        txt_msg.setVisibility(View.GONE);
        btn_neg = (TextView) view.findViewById(R.id.btn_neg);
        btn_neg.setVisibility(View.GONE);
        btn_pos = (TextView) view.findViewById(R.id.btn_pos);
        btn_pos.setVisibility(View.GONE);
        mLine = (View) view.findViewById(R.id.line);
        mDialogRoot.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (dialog != null && mCancel) {
                    dialog.dismiss();
                }
            }
        });
        // 定义Dialog布局和参数
        dialog = new Dialog(context, R.style.AlertDialogStyle);
//        dialog.getWindow().setWindowAnimations(R.style.dialog_animations);

        dialog.setContentView(view);
        return this;
    }

    /**
     * 设置自动关闭对话框的时间
     *
     * @param autoDismissTime 关闭时间长度
     * @return 当前帮助类
     */
    public LzAlertDialog setAutoDismissTime(int autoDismissTime) {
        mMillisInFuture = autoDismissTime;
        startTimer();
        return this;
    }

    public LzAlertDialog setTitle(String title) {
        if (!TextUtils.isEmpty(title)) {
            showTitle = true;
            txt_title.setText(title);
        }
        return this;
    }

    public LzAlertDialog setMsg(String msg) {
        showMsg = true;
        if (TextUtils.isEmpty(msg)) {
            txt_msg.setText("请输入提示内容");
        } else {
            txt_msg.setText(msg);
        }
        return this;
    }

    public LzAlertDialog setContentView(View view) {
        showContentView = true;
        if (view == null) {
            showContentView = false;
        } else {
            try {
                view.setLayoutParams(
                        new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT,
                                ViewGroup.LayoutParams.WRAP_CONTENT));
            } catch (Exception e) {
                e.printStackTrace();
            }
            mFrameLayout.addView(view);
        }
        return this;
    }

    public LzAlertDialog setCancelable(boolean cancel) {
        mCancel = cancel;
        dialog.setCancelable(cancel);
        return this;
    }

    /**
     * 确定按钮自带取消dialog
     *
     * @param text
     * @param listener
     * @return
     */
    public LzAlertDialog setPositiveButton(String text,
                                           final OnClickListener listener) {
        showPosBtn = true;
        if (TextUtils.isEmpty(text)) {
            btn_pos.setText("确定");
        } else {
            btn_pos.setText(text);
        }
        btn_pos.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });
        return this;
    }

    /**
     * 确定按钮不带取消的diaglog
     *
     * @param text
     * @param listener
     * @return
     */
    public LzAlertDialog setConfirmButton(String text,
                                          final OnClickListener listener) {
        showPosBtn = true;
        if (TextUtils.isEmpty(text)) {
            btn_pos.setText("确定");
        } else {
            btn_pos.setText(text);
        }
        btn_pos.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });
        return this;
    }

    public LzAlertDialog setNegativeButton(String text,
                                           final OnClickListener listener) {
        showNegBtn = true;
        if (TextUtils.isEmpty(text)) {
            btn_neg.setText("取消");
        } else {
            btn_neg.setText(text);
        }
        btn_neg.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                if (listener != null) {
                    listener.onClick(v);
                }
            }
        });
        return this;
    }

    /**
     * dialog  dismiss监听
     *
     * @param onDismisListener
     */
    public LzAlertDialog setOnDismisListener(DialogInterface.OnDismissListener onDismisListener) {
        if (onDismisListener != null) {
            dialog.setOnDismissListener(onDismisListener);
        }
        return this;
    }


    private void setLayout() {
        if (!showTitle) {
            txt_title.setVisibility(View.GONE);
        } else {
            txt_title.setVisibility(View.VISIBLE);
        }

        if (showMsg) {
            txt_msg.setVisibility(View.VISIBLE);
        } else {
            txt_msg.setVisibility(View.GONE);
        }
        if (showContentView) {
            mFrameLayout.setVisibility(View.VISIBLE);
        } else {
            mFrameLayout.setVisibility(View.GONE);
        }

        if (showPosBtn) {
            btn_pos.setVisibility(View.VISIBLE);
        } else {

            btn_pos.setVisibility(View.GONE);
        }
        if (showNegBtn) {
            btn_neg.setVisibility(View.VISIBLE);
        } else {
            btn_neg.setVisibility(View.GONE);
        }

        if (!showPosBtn && !showNegBtn) {
            ll_btn_group.setVisibility(View.GONE);
            mLine.setVisibility(View.INVISIBLE);
        } else {
            ll_btn_group.setVisibility(View.VISIBLE);
        }

        setFullScreen();

    }

    /**
     * 设置全屏显示
     */
    public void setFullScreen() {
        Window window = dialog.getWindow();
        WindowManager.LayoutParams lp = window.getAttributes();
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = LzScreenUtils.getScreenHeight();
        lp.gravity = Gravity.CENTER;
        window.setAttributes(lp);
        dialog.getWindow().setType(WindowManager.LayoutParams.TYPE_SYSTEM_ALERT);

    }

    /**
     * 显示出对话框
     *
     * @return 返回对话框对象
     */
    public LzAlertDialog show() {
        try {
            setLayout();

            dialog.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return mLpAlertDialog;
    }


    /**
     * 供外部调用关闭对话框
     */
    public void dismiss() {
        try {
            dialog.dismiss();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * 对话框是否展示
     *
     * @return true-展示中，false-没有展示
     */
    public boolean isShowing() {
        if (dialog != null) {
            dialog.isShowing();
        }
        return false;
    }

    /**
     * 开启时间计时器，一般是调用接口成功后手动调用此方法进行倒计时开启操作
     */
    public void startTimer() {
        t = new Timer();
        tt = new TimerTask() {

            @Override
            public void run() {
                han.sendEmptyMessage(0x01);
            }
        };

        t.schedule(tt, 0, mCountDownInterval);
    }

    @SuppressLint("HandlerLeak")
    Handler han = new Handler() {
        public void handleMessage(android.os.Message msg) {
            mMillisInFuture -= mCountDownInterval;
            if (mMillisInFuture < 0) {
                dismiss();
                clearTimer();
            }
        }
    };

    /**
     * 释放资源
     */
    private void clearTimer() {
        if (tt != null) {
            tt.cancel();
            tt = null;
        }
        if (t != null)
            t.cancel();
        t = null;
    }

    /**
     * 和activity的onDestroy()方法同步
     */
    public void onDestroy() {
        clearTimer();
    }


    /**
     * 设置确定是否可以点击
     *
     * @param clickable
     */
    public LzAlertDialog setBtnPosClickable(boolean clickable) {
        btn_pos.setClickable(clickable);
        return this;
    }

    /**
     * 设置取消是否可以点击`
     *
     * @param clickable
     */
    public LzAlertDialog setBtnNegClickable(boolean clickable) {
        btn_neg.setClickable(clickable);
        return this;
    }

}
