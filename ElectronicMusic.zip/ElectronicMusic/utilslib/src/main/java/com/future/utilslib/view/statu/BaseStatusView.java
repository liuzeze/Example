package com.future.utilslib.view.statu;

import android.content.Context;
import android.support.annotation.ColorRes;
import android.support.annotation.LayoutRes;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;

import com.future.utilslib.R;

/**
 * @author : liuze
 * @e-mail : 835052259@qq.com
 * @date : 2019/10/9-11:19
 * @desc : 修改内容
 * @version: 1.0
 */
public  class BaseStatusView extends FrameLayout {
    protected final StatusViewHolder viewHolder;

    public BaseStatusView(Context context, @LayoutRes int resourceId) {
        super(context);
        View view = LayoutInflater.from(context).inflate(resourceId, null);
        addView(view);
        viewHolder = StatusViewHolder.create(view);
    }

    public BaseStatusView(Context context,  View view) {
        super(context);
        addView(view);
        viewHolder = StatusViewHolder.create(view);
    }

    public StatusViewHolder getViewHolder() {
        return viewHolder;
    }


    public BaseStatusView setImgVisible(boolean isVisible) {
        viewHolder.setVisibility(R.id.image, isVisible);
        return this;
    }

    public BaseStatusView setLoading(boolean isVisible) {
        viewHolder.setVisibility(R.id.progressbar, isVisible);
        return this;
    }

    public BaseStatusView setImgRes(int ivRes) {
        viewHolder.setImageResource(R.id.image, ivRes);
        return this;
    }

    public BaseStatusView setTextVisible(boolean isVisible) {
        viewHolder.setVisibility(R.id.tv_text1, isVisible);
        return this;
    }

    public BaseStatusView setTextColor(@ColorRes int color) {
        viewHolder.setTextColor(R.id.tv_text1, viewHolder.getConvertView().getResources().getColor(color));
        return this;
    }

    public BaseStatusView setText(String text) {
        viewHolder.setText(R.id.tv_text1, text);
        return this;
    }

    public BaseStatusView setTextSize(int textSize) {
        viewHolder.setTextSize(R.id.tv_text1, textSize);
        return this;
    }

    public BaseStatusView setRetryVisible(boolean isVisible) {
        viewHolder.setVisibility(R.id.tv_text2, isVisible);
        return this;
    }

    public BaseStatusView setRetryTextColor(@ColorRes int color) {
        viewHolder.setTextColor(R.id.tv_text2, viewHolder.getConvertView().getResources().getColor(color));
        return this;
    }

    public BaseStatusView setRetryText(String text) {
        viewHolder.setText(R.id.tv_text2, text);
        return this;
    }

    public BaseStatusView setRetryTextSize(int textSize) {
        viewHolder.setTextSize(R.id.tv_text2, textSize);
        return this;
    }

    public BaseStatusView setTextClick(View.OnClickListener errorTextClick) {
        viewHolder.setOnClickListener(R.id.tv_text1, errorTextClick);
        return this;
    }


    public BaseStatusView setRetryClick(View.OnClickListener errorTextClick) {
        viewHolder.setOnClickListener(R.id.tv_text2, errorTextClick);
        return this;
    }

    public BaseStatusView setRetryBackGround(int bgRes) {
        viewHolder.setBackgroundResource(R.id.tv_text2, bgRes);
        return this;
    }
}
