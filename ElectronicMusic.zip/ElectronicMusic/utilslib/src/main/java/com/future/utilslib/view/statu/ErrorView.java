package com.future.utilslib.view.statu;

import android.content.Context;

import com.future.utilslib.R;

/**
 * @author : liuze
 * @e-mail : 835052259@qq.com
 * @date : 2019/10/9-10:55
 * @desc : 修改内容
 * @version: 1.0
 */
public class ErrorView extends BaseStatusView {


    public ErrorView(Context context ) {
        super(context, R.layout.layout_status);
        setImgVisible(true)
                .setImgRes(R.mipmap.error)
                .setText("似乎出了点问题")
                .setTextVisible(true)
                .setRetryText("点我重试")

        ;
    }
}
