package com.future.electronicmusic.logic;

/**
 * -----------作者----------日期----------变更内容-----
 * -          刘泽      2019-07-17       创建class
 */
public interface Constants {


    String UETOOL_Check = "UETOOL_Check";

}
